function saveDataCash(conta)
    if conta then
        local source = getAccountPlayer(conta)
        if isElement(source) then
            local Cash =  getElementData(source,"conta.Cash") or 0
            setAccountData(conta, "conta.Cash",tonumber(Cash))
        end
    end 
end

function loadDataCash(conta)
    if not (isGuestAccount (conta)) then
        if (conta) then 
            local source = getAccountPlayer(conta)  
            if isElement(source) then
                local Cash = getAccountData(conta,"conta.Cash")
                if type(Cash) == "boolean" or "conta.Cash" == nil then
                    Cash = 0
                end
                setElementData(source, "conta.Cash", tonumber(Cash))
                outputDebugString("Carregando Cash: "..Cash)     
            end
        end
    end 
end

addEventHandler("onPlayerLogin", root, function(_, acc)
    setTimer(loadDataCash,1000,1,acc)
end)

function saveOnStartScriptCash(res)
    if res == getThisResource() then
        for i, player in ipairs(getElementsByType("player")) do
            local acc = getPlayerAccount(player)
            if not isGuestAccount(acc) then
                loadDataCash(acc)           
            end
        end
    end
end
addEventHandler("onResourceStart", getRootElement(), saveOnStartScriptCash)

function saveOnStopScriptCash(res)
    if res == getThisResource() then
        for i, player in ipairs(getElementsByType("player")) do
            local acc = getPlayerAccount(player)
            if not isGuestAccount(acc) then
                saveDataCash(acc)   
            end
        end
    end
end 
addEventHandler("onResourceStop", getRootElement(), saveOnStopScriptCash)

function saveOnQuitCash(quitType)
    local acc = getPlayerAccount(source)
    if not (isGuestAccount(acc)) then
        if acc then
            saveDataCash(acc)
        end
    end
end
addEventHandler("onPlayerQuit", getRootElement(), saveOnQuitCash)