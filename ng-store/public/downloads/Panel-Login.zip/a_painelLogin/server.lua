addEvent("hasClickLogin", true)
addEventHandler("hasClickLogin", getRootElement(), 
	function(username, password)
		if username == "" then
			showInfobox(source, "error", "Preencha seu nome de usuario")
			return
		end

		if password == "" then
			showInfobox(source, "error", "Preencha sua senha")
			return
		end

		local account = getAccount(username, password)

		if account == false then
			showInfobox(source, "error", "Esse nome de usuario ou senha não existe")
			return
		end

		logIn(source, account, password)
		showInfobox(source, "info", "Você fez o login com sucesso")
		triggerClientEvent(source, "removeLogin", root)
		setPedWalkingStyle(source, 118)
	end
)

addEvent("hasClickRegister", true)
addEventHandler("hasClickRegister", getRootElement(),
	function(username, password, email)
		if username == "" then
			showInfobox(source, "error", "Preencha seu nome de usuario")
			return
		end

		if password == "" then
			showInfobox(source, "error", "Preencha sua senha")
			return
		end

		if email == "" then
			showInfobox(source, "error", "Preencha sua senha de confirmação")
			return
		end
		local account = getAccount(username, password)
		if account then
			showInfobox(source, "error", "Ja existe uma conta com o mesmo nome e mesma senha")
			return
		end
		if (#getAccountsBySerial(getPlayerSerial(source)) > 2) then
			showInfobox(source, "error", "Você so pode criar maximo 2 contas")
			return
		end
		local accountAdded = addAccount(tostring(username), tostring(password)) 
		if not accountAdded then
			showInfobox(source, "error", "Tente novamente com Novo Usuário e Senha")
			return
		end
		logIn(source, accountAdded, password)
		showInfobox(source, "info", "Registrado com Sucesso", "Usuario: " .. username .. " | Senha: " .. password .. "")
		triggerClientEvent(source, "removeLogin", root)
	end
)

addEventHandler("onPlayerJoin", getRootElement(),
	function()
		spawnPlayer(source, 1642.324, -2334.318, 13.547, 0, 0)
		setElementRotation(source, -0, 0, 0.813)
		setCameraTarget(source, source)
		givePlayerMoney(source, 1000)
		fadeCamera(source, true)
	end
)

function showInfobox(element, type, msg, msg2, imgPath, color)
	if isElement(element) then
		triggerClientEvent(element, "showInfobox", element, type, msg, msg2, imgPath, color)
	end
end